# ⚡ NEXORA — AI-Powered Creator Portfolio Website

A premium, cinematic full-stack portfolio website for **Nexora** by **M.J.B**.

---

## 📁 Folder Structure

```
nexora-portfolio/
├── index.html          ← Frontend (single file, self-contained)
├── server.js           ← Backend API (Node.js + Express)
├── package.json        ← Dependencies
├── .env.example        ← Environment variables template
├── .env                ← Your real config (create from .env.example)
└── README.md
```

---

## 🚀 Quick Start (Local)

### 1. Prerequisites
- [Node.js](https://nodejs.org) v18+ installed
- [MongoDB](https://www.mongodb.com/try/download/community) running locally OR a free [MongoDB Atlas](https://cloud.mongodb.com) account

### 2. Install dependencies
```bash
npm install
```

### 3. Configure environment
```bash
cp .env.example .env
# Then edit .env with your MongoDB URI, email credentials, etc.
```

### 4. Set up Gmail App Password (for email notifications)
1. Go to [Google Account Security](https://myaccount.google.com/security)
2. Enable **2-Step Verification**
3. Go to **App passwords** → Create one for "Mail"
4. Copy the 16-character password into `.env` as `EMAIL_PASS`

### 5. Run the server
```bash
# Development (auto-restart on changes)
npm run dev

# Production
npm start
```

### 6. Open the website
```
http://localhost:3000
```

---

## 🌐 What Each Part Does

| File | Purpose |
|------|---------|
| `index.html` | Complete frontend — hero, about, services, portfolio, form, contact, chatbot |
| `server.js` | Express API — form submissions, MongoDB storage, email notifications |
| `.env` | Secret config — DB URI, email credentials, admin key |

---

## 🔌 API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| `POST` | `/api/apply` | Submit application form |
| `GET` | `/api/applications` | List all applications (admin) |
| `PATCH` | `/api/applications/:id` | Update application status (admin) |

### Admin access
Add header `x-admin-key: your-ADMIN_KEY` to access protected endpoints.

```bash
# Example: Get all applications
curl -H "x-admin-key: nexora-super-secret-key-change-this" \
  http://localhost:3000/api/applications
```

---

## 🔧 Connecting the Form to the Backend

In `index.html`, find the `submitForm()` function and replace the `setTimeout` simulation with a real fetch:

```javascript
async function submitForm() {
  // ... validation code stays the same ...
  btn.disabled = true; btn.textContent = '⟳ SENDING...';
  try {
    const res = await fetch('/api/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, phone, service, message })
    });
    const data = await res.json();
    if (data.success) {
      status.innerHTML = `<div class="success-msg">✓ ${data.message}</div>`;
      // clear fields...
    } else {
      status.innerHTML = `<div class="error-msg">⚠ ${data.error}</div>`;
    }
  } catch (e) {
    status.innerHTML = `<div class="error-msg">⚠ Connection error. Please try again.</div>`;
  }
  btn.disabled = false; btn.textContent = '⚡ Submit Application';
}
```

---

## ☁️ Deploy to Production

### Option A — Railway (Recommended, free tier)
1. Push this folder to a GitHub repo
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add MongoDB plugin
4. Set environment variables in the Railway dashboard
5. Done — live URL in ~2 minutes

### Option B — Vercel + MongoDB Atlas
1. Use Vercel for frontend (just `index.html`)
2. Host backend separately on Railway or Render
3. Update fetch URL in `submitForm()` to your backend URL

### Option C — VPS / DigitalOcean
```bash
git clone your-repo && cd nexora-portfolio
npm install
cp .env.example .env && nano .env
npm install -g pm2
pm2 start server.js --name nexora
pm2 save && pm2 startup
```

---

## 🎨 Customization

| What to change | Where |
|---------------|-------|
| Business name | Search "NEXORA" in `index.html` |
| Founder name | Search "M.J.B" in `index.html` |
| Phone/Email | Search "1234567890" / "xyz@gmail.com" |
| Services | Edit `services` array in `<script>` |
| Portfolio projects | Edit `projects` array in `<script>` |
| Colors | Edit `:root` CSS variables at top of `<style>` |
| Chatbot replies | Edit `chatReplies` object in `<script>` |

---

## 📦 Tech Stack

**Frontend**
- Pure HTML5 + CSS3 (no build step needed!)
- Vanilla JavaScript (ES6+)
- Google Fonts (Orbitron + Rajdhani)
- Web Canvas API for water animation
- IntersectionObserver for scroll reveals
- Custom cursor + scroll progress bar

**Backend**
- Node.js + Express.js
- MongoDB + Mongoose ODM
- Nodemailer (Gmail SMTP)
- CORS + dotenv

---

## 🔒 Security Notes

- Change `ADMIN_KEY` in `.env` before deploying
- Never commit `.env` to git (add it to `.gitignore`)
- For production, set `ALLOWED_ORIGIN` to your domain
- Use HTTPS in production (Railway/Vercel handle this automatically)

---

Built with ⚡ by **M.J.B** · Nexora Studio · India
