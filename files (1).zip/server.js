// server.js — Nexora Backend API
// Stack: Node.js + Express + MongoDB + Nodemailer
const express = require('express');
const mongoose = require('mongoose');
const nodemailer = require('nodemailer');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── MongoDB Connection ──
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/nexora')
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB error:', err));

// ── Application Schema ──
const applicationSchema = new mongoose.Schema({
  name:      { type: String, required: true },
  email:     { type: String, required: true },
  phone:     { type: String },
  service:   { type: String, required: true },
  message:   { type: String, required: true },
  status:    { type: String, default: 'new', enum: ['new', 'reviewed', 'contacted', 'closed'] },
  createdAt: { type: Date, default: Date.now }
});
const Application = mongoose.model('Application', applicationSchema);

// ── Email Transporter ──
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || 'xyz@gmail.com',
    pass: process.env.EMAIL_PASS || 'your-app-password-here'
  }
});

// ── POST /api/apply — Submit Application ──
app.post('/api/apply', async (req, res) => {
  const { name, email, phone, service, message } = req.body;
  if (!name || !email || !service || !message) {
    return res.status(400).json({ success: false, error: 'Missing required fields.' });
  }
  try {
    // Save to MongoDB
    const app_entry = await Application.create({ name, email, phone, service, message });

    // Email to founder
    await transporter.sendMail({
      from: `"Nexora Bot" <${process.env.EMAIL_USER}>`,
      to: process.env.FOUNDER_EMAIL || 'xyz@gmail.com',
      subject: `🚀 New Application from ${name}`,
      html: `
        <div style="font-family:sans-serif;background:#0a0a0a;color:#e2e8f0;padding:30px;border-radius:8px">
          <h2 style="color:#0ea5e9;font-family:monospace">NEXORA — New Application</h2>
          <table style="width:100%;border-collapse:collapse">
            <tr><td style="padding:8px 0;color:#64748b">Name</td><td style="padding:8px 0;font-weight:600">${name}</td></tr>
            <tr><td style="padding:8px 0;color:#64748b">Email</td><td style="padding:8px 0">${email}</td></tr>
            <tr><td style="padding:8px 0;color:#64748b">Phone</td><td style="padding:8px 0">${phone || 'N/A'}</td></tr>
            <tr><td style="padding:8px 0;color:#64748b">Service</td><td style="padding:8px 0;color:#0ea5e9">${service}</td></tr>
          </table>
          <h3 style="color:#0ea5e9;margin-top:20px">Message:</h3>
          <p style="background:#111;padding:16px;border-left:3px solid #0ea5e9;border-radius:4px">${message}</p>
          <p style="color:#64748b;margin-top:20px;font-size:12px">Application ID: ${app_entry._id}</p>
        </div>
      `
    });

    // Auto-reply to applicant
    await transporter.sendMail({
      from: `"Nexora Studio" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: '⚡ We received your application — Nexora',
      html: `
        <div style="font-family:sans-serif;background:#0a0a0a;color:#e2e8f0;padding:30px;border-radius:8px">
          <h2 style="color:#0ea5e9;font-family:monospace">NEXORA</h2>
          <p>Hi <strong>${name}</strong>,</p>
          <p>Your application has been received! We'll review your project requirements and get back to you within <strong style="color:#0ea5e9">24 hours</strong>.</p>
          <p>Here's what you submitted:</p>
          <table style="width:100%;border-collapse:collapse;background:#111;padding:16px;border-radius:8px">
            <tr><td style="padding:8px;color:#64748b">Service</td><td style="padding:8px;color:#0ea5e9">${service}</td></tr>
            <tr><td style="padding:8px;color:#64748b">Message</td><td style="padding:8px">${message}</td></tr>
          </table>
          <p style="margin-top:24px">Questions? Reply to this email or WhatsApp us at 1234567890.</p>
          <p style="color:#64748b;margin-top:24px;font-size:12px">M.J.B · Nexora Studio · India</p>
        </div>
      `
    });

    res.json({ success: true, message: `Application received! Check ${email} for confirmation.`, id: app_entry._id });
  } catch (err) {
    console.error('Application error:', err);
    res.status(500).json({ success: false, error: 'Server error. Please try again.' });
  }
});

// ── GET /api/applications — Admin: List all apps ──
app.get('/api/applications', async (req, res) => {
  const secret = req.headers['x-admin-key'];
  if (secret !== process.env.ADMIN_KEY) return res.status(401).json({ error: 'Unauthorized' });
  const apps = await Application.find().sort({ createdAt: -1 });
  res.json({ success: true, count: apps.length, data: apps });
});

// ── PATCH /api/applications/:id — Update status ──
app.patch('/api/applications/:id', async (req, res) => {
  const secret = req.headers['x-admin-key'];
  if (secret !== process.env.ADMIN_KEY) return res.status(401).json({ error: 'Unauthorized' });
  const updated = await Application.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  res.json({ success: true, data: updated });
});

// ── Serve frontend ──
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Nexora server running on http://localhost:${PORT}`));
